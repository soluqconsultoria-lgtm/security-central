# Central de Segurança Android (v0.2)

Android 13+ · Kotlin · Compose · MVVM + Clean Architecture · módulos Gradle.

| Módulo | Conteúdo |
|---|---|
| `core-domain` | Motor de risco, regras heurísticas (Camada 3 do MDE), testes unitários |
| `feature-ai-inventory` | Catálogo de apps de IA, permissões, origem da instalação |
| `feature-malware` | MDE Camadas 1 e 2: SHA-256 do APK, certificados, base de ameaças local |
| `app` | ViewModel + tela em Compose |

Próximos: `feature-privacy`, `feature-network` (VPN local), `feature-intelligence`, Room, WorkManager, Hilt.

## Como rodar
1. Abra no Android Studio (ele gera o Gradle wrapper).
2. Testes: `./gradlew :core-domain:test`.
3. Rode em um aparelho ou emulador com Android 13+.

## Limites conhecidos
- Código escrito sem compilação: revise versões de dependências na primeira sincronização.
- O app só enxerga os pacotes declarados em `<queries>` no manifesto. Para escanear todos os apps,
  seria preciso QUERY_ALL_PACKAGES, que a Google Play restringe e exige justificativa.
- A base de ameaças está vazia: sem fonte de reputação, só a heurística funciona.
