package com.securitycentral.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: SecurityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val state by vm.state.collectAsState()
                Scaffold { pad ->
                    LazyColumn(
                        Modifier.padding(pad).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        item {
                            Text("Central de Segurança", style = MaterialTheme.typography.titleLarge)
                            Text("Indícios de risco, não garantia de limpeza.", style = MaterialTheme.typography.bodySmall)
                        }
                        item { Button(onClick = vm::refresh) { Text("Analisar novamente") } }
                        if (state.loading) item { CircularProgressIndicator() }
                        else if (state.cards.isEmpty()) item { Text("Nenhum app de IA do catálogo instalado.") }
                        items(state.cards) { card ->
                            val r = card.report
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("${r.appLabel}: ${r.level} (${r.score}/100)", style = MaterialTheme.typography.titleMedium)
                                    if (r.evidences.isEmpty()) Text("Nenhuma evidência de risco encontrada.")
                                    r.evidences.forEach { Text("• ${it.description}") }
                                    Text(r.recommendation)
                                    Text("APK SHA-256: ${card.apkSha256.take(16)}…", style = MaterialTheme.typography.labelSmall)
                                    Text("Certificado SHA-256: ${card.signerSha256.take(16)}…", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
