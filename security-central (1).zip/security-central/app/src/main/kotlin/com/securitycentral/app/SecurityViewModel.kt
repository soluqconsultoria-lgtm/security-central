package com.securitycentral.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.securitycentral.domain.AppRiskReport
import com.securitycentral.domain.RiskEngine
import com.securitycentral.inventory.InstalledAppsScanner
import com.securitycentral.malware.LocalThreatIntel
import com.securitycentral.malware.MalwareScanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AppCard(val report: AppRiskReport, val apkSha256: String, val signerSha256: String)

data class UiState(val loading: Boolean = true, val cards: List<AppCard> = emptyList())

class SecurityViewModel(app: Application) : AndroidViewModel(app) {
    private val inventory = InstalledAppsScanner(app)
    private val malware = MalwareScanner(app, LocalThreatIntel())
    private val engine = RiskEngine()

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        _state.value = UiState(loading = true)
        viewModelScope.launch {
            val apps = inventory.scan()
            val findings = malware.scan(apps.map { it.packageName }).associateBy { it.facts.packageName }
            val cards = apps.map { app ->
                val finding = findings[app.packageName]
                val evidences = inventory.privacyEvidences(app) + finding?.evidences.orEmpty()
                val report = engine.assess(app.packageName, app.label, evidences.distinctBy { it.code })
                AppCard(
                    report = report,
                    apkSha256 = finding?.facts?.apkSha256 ?: "indisponível",
                    signerSha256 = finding?.facts?.signerSha256?.firstOrNull() ?: "indisponível",
                )
            }.sortedByDescending { it.report.score }
            _state.value = UiState(loading = false, cards = cards)
        }
    }
}
