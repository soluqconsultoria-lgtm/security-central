package com.securitycentral.domain

/**
 * Camada 3 do MDE: heurística por COMBINAÇÃO de sinais.
 * Nenhuma permissão isolada gera alerta alto. Comece com poucas regras e valide em testes.
 */
object HeuristicRules {
    private const val SMS_READ = "android.permission.READ_SMS"
    private const val SMS_RECEIVE = "android.permission.RECEIVE_SMS"
    private const val OVERLAY = "android.permission.SYSTEM_ALERT_WINDOW"
    private const val INSTALL_PKGS = "android.permission.REQUEST_INSTALL_PACKAGES"
    private const val MIC = "android.permission.RECORD_AUDIO"
    private const val CAMERA = "android.permission.CAMERA"
    private const val CONTACTS = "android.permission.READ_CONTACTS"
    private const val LOCATION = "android.permission.ACCESS_FINE_LOCATION"
    const val PLAY_STORE = "com.android.vending"

    fun evaluate(permissions: Set<String>, installer: String?, multipleSigners: Boolean): List<Evidence> {
        val out = mutableListOf<Evidence>()
        val sideloaded = installer != PLAY_STORE

        if ((SMS_READ in permissions || SMS_RECEIVE in permissions) && OVERLAY in permissions) {
            out += Evidence(EvidenceSource.MALWARE, "SMS_OVERLAY",
                "Lê SMS e pode desenhar sobre outras telas (combinação comum em roubo de códigos)", 25)
        }
        if (INSTALL_PKGS in permissions && sideloaded) {
            out += Evidence(EvidenceSource.MALWARE, "INSTALLER_SIDELOAD",
                "Pode instalar outros apps e foi instalado fora da Play Store", 20)
        }
        if (setOf(MIC, CAMERA, CONTACTS, LOCATION).all { it in permissions }) {
            out += Evidence(EvidenceSource.PRIVACY, "SENSITIVE_BUNDLE",
                "Reúne microfone, câmera, contatos e localização precisa", 12)
        }
        if (multipleSigners) {
            out += Evidence(EvidenceSource.MALWARE, "MULTI_SIGNER",
                "Pacote com mais de um certificado de assinatura (verificar)", 10)
        }
        return out
    }
}
