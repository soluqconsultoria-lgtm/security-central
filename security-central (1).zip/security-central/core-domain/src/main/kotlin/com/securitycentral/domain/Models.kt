package com.securitycentral.domain

enum class RiskLevel { LOW, MODERATE, HIGH, CRITICAL }

enum class EvidenceSource { INVENTORY, PRIVACY, MALWARE, NETWORK }

/** Uma evidência isolada. Nunca vira alerta sozinha, a menos que seja [confirmedMalware]. */
data class Evidence(
    val source: EvidenceSource,
    val code: String,
    val description: String,
    val weight: Int,
    val confirmedMalware: Boolean = false,
)

data class AppRiskReport(
    val packageName: String,
    val appLabel: String,
    val score: Int,
    val level: RiskLevel,
    val evidences: List<Evidence>,
    val recommendation: String,
)
