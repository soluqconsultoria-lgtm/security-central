package com.securitycentral.domain

/**
 * Motor de correlação. Regras de projeto:
 *  - permissão isolada não é vírus (peso baixo);
 *  - nota 0..100 sempre acompanhada da lista de evidências;
 *  - correspondência confirmada com malware força CRITICAL.
 */
class RiskEngine(
    private val lowMax: Int = 24,
    private val moderateMax: Int = 49,
    private val highMax: Int = 74,
) {
    fun assess(packageName: String, appLabel: String, evidences: List<Evidence>): AppRiskReport {
        val confirmed = evidences.any { it.confirmedMalware }
        val base = evidences.sumOf { it.weight }
        val bonus = if (evidences.map { it.source }.distinct().size >= 2) 10 else 0 // correlação entre fontes
        val score = if (confirmed) 100 else (base + bonus).coerceIn(0, 100)
        val level = when {
            confirmed -> RiskLevel.CRITICAL
            score <= lowMax -> RiskLevel.LOW
            score <= moderateMax -> RiskLevel.MODERATE
            score <= highMax -> RiskLevel.HIGH
            else -> RiskLevel.CRITICAL
        }
        return AppRiskReport(packageName, appLabel, score, level, evidences, recommendationFor(level))
    }

    private fun recommendationFor(level: RiskLevel) = when (level) {
        RiskLevel.LOW -> "Nenhuma ação necessária."
        RiskLevel.MODERATE -> "Revise as permissões concedidas a este app."
        RiskLevel.HIGH -> "Considere revogar permissões sensíveis ou desinstalar."
        RiskLevel.CRITICAL -> "Desinstale o app e verifique suas contas."
    }
}
