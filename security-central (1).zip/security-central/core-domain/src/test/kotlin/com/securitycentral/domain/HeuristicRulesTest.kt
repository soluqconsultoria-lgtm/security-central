package com.securitycentral.domain

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class HeuristicRulesTest {
    @Test fun `permissao isolada nao gera evidencia`() {
        val e = HeuristicRules.evaluate(setOf("android.permission.CAMERA"), "com.android.vending", false)
        assertTrue(e.isEmpty())
    }

    @Test fun `sms mais overlay gera evidencia`() {
        val e = HeuristicRules.evaluate(
            setOf("android.permission.READ_SMS", "android.permission.SYSTEM_ALERT_WINDOW"),
            "com.android.vending", false,
        )
        assertEquals(listOf("SMS_OVERLAY"), e.map { it.code })
    }

    @Test fun `instalador de pacotes fora da play gera evidencia`() {
        val e = HeuristicRules.evaluate(setOf("android.permission.REQUEST_INSTALL_PACKAGES"), null, false)
        assertEquals(listOf("INSTALLER_SIDELOAD"), e.map { it.code })
    }
}
