package com.securitycentral.domain

import kotlin.test.Test
import kotlin.test.assertEquals

class RiskEngineTest {
    private val engine = RiskEngine()

    @Test fun `permissao isolada nao vira alerta alto`() {
        val r = engine.assess("a.b", "App", listOf(Evidence(EvidenceSource.PRIVACY, "MIC", "Usa microfone", 10)))
        assertEquals(RiskLevel.LOW, r.level)
    }

    @Test fun `malware confirmado forca critico`() {
        val r = engine.assess("a.b", "App", listOf(Evidence(EvidenceSource.MALWARE, "HASH", "Hash conhecido", 5, confirmedMalware = true)))
        assertEquals(RiskLevel.CRITICAL, r.level)
        assertEquals(100, r.score)
    }
}
