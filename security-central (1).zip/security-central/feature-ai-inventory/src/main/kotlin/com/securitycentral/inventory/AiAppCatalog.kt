package com.securitycentral.inventory

/** Catálogo inicial de pacotes de IA conhecidos. VERIFICAR cada nome antes de publicar. */
object AiAppCatalog {
    val knownPackages: Map<String, String> = mapOf(
        "com.openai.chatgpt" to "ChatGPT",
        "com.google.android.apps.bard" to "Gemini",
        "com.microsoft.copilot" to "Microsoft Copilot",
        "com.anthropic.claude" to "Claude",
        "ai.perplexity.app.android" to "Perplexity",
        "com.deepseek.chat" to "DeepSeek",
    )
}
