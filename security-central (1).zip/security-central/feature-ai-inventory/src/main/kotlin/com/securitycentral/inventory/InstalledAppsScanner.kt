package com.securitycentral.inventory

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import com.securitycentral.domain.Evidence
import com.securitycentral.domain.EvidenceSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
    val packageName: String,
    val label: String,
    val installer: String?,
    val grantedPermissions: List<String>,
    val isKnownAi: Boolean,
)

class InstalledAppsScanner(private val context: Context) {

    suspend fun scan(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        // Para publicar na Play, evite QUERY_ALL_PACKAGES: declare <queries> com os pacotes do catálogo.
        AiAppCatalog.knownPackages.keys.mapNotNull { pkg -> runCatching { toApp(pm, pkg) }.getOrNull() }
    }

    private fun toApp(pm: PackageManager, pkg: String): InstalledApp {
        val info: PackageInfo = pm.getPackageInfo(
            pkg, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
        )
        val granted = info.requestedPermissions.orEmpty().filterIndexed { i, _ ->
            (info.requestedPermissionsFlags?.getOrNull(i) ?: 0) and
                android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED != 0
        }
        val installer = pm.getInstallSourceInfo(pkg).installingPackageName
        return InstalledApp(
            packageName = pkg,
            label = pm.getApplicationLabel(info.applicationInfo!!).toString(),
            installer = installer,
            grantedPermissions = granted,
            isKnownAi = true,
        )
    }

    /** Converte permissões sensíveis em evidências de baixo peso (nunca alerta por si só). */
    fun privacyEvidences(app: InstalledApp): List<Evidence> {
        val sensitive = mapOf(
            "android.permission.RECORD_AUDIO" to "Acesso ao microfone",
            "android.permission.CAMERA" to "Acesso à câmera",
            "android.permission.READ_CONTACTS" to "Leitura de contatos",
            "android.permission.ACCESS_FINE_LOCATION" to "Localização precisa",
        )
        val list = app.grantedPermissions.mapNotNull { p ->
            sensitive[p]?.let { Evidence(EvidenceSource.PRIVACY, p.substringAfterLast('.'), it, 8) }
        }.toMutableList()
        if (app.installer != "com.android.vending") {
            list += Evidence(EvidenceSource.INVENTORY, "SIDELOAD", "Instalado fora da Play Store", 20)
        }
        return list
    }
}
