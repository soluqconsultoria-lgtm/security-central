pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositories { google(); mavenCentral() }
}
rootProject.name = "security-central"
include(":app", ":core-domain", ":feature-ai-inventory", ":feature-malware")
// Próximos módulos: :feature-privacy, :feature-network, :feature-intelligence
